"use client";

import { useSession } from "next-auth/react";

export default function TestPage() {
  const { data: session, status } = useSession();

  console.log(session);

  return (
    <div>
      <h1>Test Page</h1>
      <p>Status: {status}</p>
      <p>User: {session?.user?.email || "Not logged in"}</p>
    </div>
  );
}
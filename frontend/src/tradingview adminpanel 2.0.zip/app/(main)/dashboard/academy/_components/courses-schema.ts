import z from "zod";

export const courseSchema = z.object({
  id: z.number().optional(), // The primary key (Integer)
  CourseUUID: z.string().optional(), // From your DB
  title: z.string(), // Changed from courseName
  course_id: z.string().optional(),
  description: z.string().optional().nullable(), // Changed from courseDescription
  price: z.number(),
  course_thumbnail: z.string().optional().nullable(),

  // We keep purchasedCount optional just so the UI doesn't break,
  // you can wire this up properly in the backend later!
  purchased_count: z.number().default(0),
});

export type CourseRow = z.infer<typeof courseSchema>;

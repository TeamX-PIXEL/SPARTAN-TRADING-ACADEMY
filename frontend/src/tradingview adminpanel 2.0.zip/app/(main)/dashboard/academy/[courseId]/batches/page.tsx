import { BatchesPageClient } from "./_components/batches-page-client";

export default function Page() {
  return <BatchesPageClient />;
}

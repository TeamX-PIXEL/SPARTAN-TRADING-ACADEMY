"use client";

import * as React from "react";
import { useParams } from "next/navigation";

import type { BatchRow } from "@/app/(main)/dashboard/academy/_components/batches-schema";
import { BatchesTable } from "@/app/(main)/dashboard/academy/_components/batches-table";
import type { ChapterRow } from "@/app/(main)/dashboard/academy/_components/chapters-columns";
import { ChaptersTable } from "@/app/(main)/dashboard/academy/_components/chapters-table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { fetchWithAuth, API_BASE_URL } from "@/lib/api-fetch";

function mapBatches(raw: any[]): BatchRow[] {
  return raw.map((batch: any) => {
    const startDate = new Date(batch.batch_start_date);
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + batch.max_days);

    return {
      id: batch.id,
      batchId: `B-${batch.id}`,
      batchName: startDate.toLocaleDateString("en-US", { month: "long", year: "numeric" }),
      startDate: startDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      endDate: endDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      status: batch.status || "scheduled",
      participants: batch.no_participants,
      progress: batch.progress ?? { scheduled: 0, total: 0 },
      rawStartDate: batch.batch_start_date,
      maxDays: batch.max_days,
    };
  });
}

function mapChapters(raw: any[]): ChapterRow[] {
  return raw.map((chap: any) => ({
    id: `chap-${chap.id}`,
    dbId: chap.id,
    name: chap.title,
    day: chap.days_after_start,
    index: chap.chapter_index,
  }));
}

export function BatchesPageClient() {
  const params = useParams<{ courseId: string }>();
  const courseId = params.courseId;

  const [batches, setBatches] = React.useState<BatchRow[]>([]);
  const [chapters, setChapters] = React.useState<ChapterRow[]>([]);
  const [courseName, setCourseName] = React.useState(`Course ${courseId}`);
  const [template, setTemplate] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (!courseId) return;

    let cancelled = false;

    async function safeFetch(url: string): Promise<any> {
      try {
        const r = await fetchWithAuth(url);
        if (!r.ok) return null;
        const text = await r.text();
        try {
          return JSON.parse(text);
        } catch {
          console.error("Non-JSON response from", url, text.slice(0, 200));
          return null;
        }
      } catch (err) {
        console.error("Fetch failed for", url, err);
        return null;
      }
    }

    async function load() {
      setLoading(true);

      const [batchesRes, coursesRes, chaptersRes, templateRes] = await Promise.all([
        safeFetch(`${API_BASE_URL}/api/admin/courses/${courseId}/batches`),
        safeFetch(`${API_BASE_URL}/api/admin/courses`),
        safeFetch(`${API_BASE_URL}/api/admin/courses/${courseId}/chapters`),
        safeFetch(`${API_BASE_URL}/api/admin/courses/${courseId}/template`),
      ]);

      if (cancelled) return;

      setBatches(mapBatches(Array.isArray(batchesRes) ? batchesRes : []));

      const courses = coursesRes?.courses || coursesRes;
      if (Array.isArray(courses)) {
        const found = courses.find((c: any) => c.id.toString() === courseId);
        if (found) setCourseName(found.title);
      }

      setChapters(mapChapters(Array.isArray(chaptersRes) ? chaptersRes : []));
      setTemplate(templateRes);
      setLoading(false);
    }

    load();

    return () => { cancelled = true; };
  }, [courseId]);

  if (loading) {
    return (
      <div className="p-6">
        <h2 className="text-3xl font-bold tracking-tight">Course Management</h2>
        <p className="mt-2 text-sm text-muted-foreground">Loading...</p>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-tight">Course Management</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Manage your course catalog and organize the shared curriculum chapters.
        </p>
      </div>

      <Tabs defaultValue="batches" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="batches">Batches</TabsTrigger>
          <TabsTrigger value="chapters">Chapters</TabsTrigger>
        </TabsList>

        <TabsContent value="batches">
          <BatchesTable data={batches} courseId={courseId} courseName={courseName} template={template} />
        </TabsContent>

        <TabsContent value="chapters">
          <div className="rounded-md border bg-card text-card-foreground shadow">
            <div className="p-6">
              <ChaptersTable initialData={chapters} courseId={courseId} />
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

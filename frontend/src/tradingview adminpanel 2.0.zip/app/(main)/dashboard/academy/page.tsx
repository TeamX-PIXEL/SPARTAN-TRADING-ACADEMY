import { redirect } from "next/navigation";

import { getServerSession } from "next-auth";

import { authOptions } from "@/lib/auth";

import { AcademyTable } from "./_components/courses-table";

export default async function AcademyDashboardPage() {
  return (
    <div className="space-y-6 p-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Academy Courses</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Manage your course catalog and select a course to view its active batches.
        </p>
      </div>

      <AcademyTable />
    </div>
  );
}

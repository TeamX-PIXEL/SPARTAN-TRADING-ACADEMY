import { differenceInCalendarDays, isValid, parseISO } from "date-fns";
import { getServerSession } from "next-auth";

import { authOptions } from "@/lib/auth";

import { type EnrollingCourseRow, EnrollingCoursesTable } from "./_components/enrolling-courses-table";
import { ExpiringSubscriptionsTable } from "./_components/expiring-subscriptions-table/columns";
import {
  type ExpiringSubscriptionRow,
  expiringSubscriptionSchema,
} from "./_components/expiring-subscriptions-table/schema";
import { RecentPurchasersTable } from "./_components/recent-purchasers-table/columns";
import type { RecentPurchaserRow } from "./_components/recent-purchasers-table/schema";
import type { RevenuePoint } from "./_components/revenue-chart";
import { RevenueByProductChart } from "./_components/revenue-chart";
import { type OverviewStats, SectionCards } from "./_components/section-cards";
import { type ModuleStatus, type SystemHealth, SystemHealthStrip } from "./_components/system-health";
import { type UpcomingSessionRow, UpcomingSessionsTable } from "./_components/upcoming-sessions-table";

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://127.0.0.1:8000";

interface CourseRow {
  id?: number;
  title?: string;
  price?: number;
  purchased_count?: number;
}

interface IndicatorRow {
  id: number;
  indicator_name: string;
  indicator_price?: number;
  buyers?: number;
  status?: "unavailable" | "paused" | "running";
}

interface BotUser {
  id: number | string;
  user?: string;
  user_key?: string;
  telegram_id?: string | number;
  Alpha_Expiry?: string | null;
  Evergreen_Expiry?: string | null;
  Legacy_Expiry?: string | null;
}

async function safeFetch<T>(
  url: string,
  init?: RequestInit,
  fallback: T = [] as unknown as T,
): Promise<{ ok: true; data: T } | { ok: false; error: unknown; data: T }> {
  try {
    const res = await fetch(url, { cache: "no-store", ...init });
    if (!res.ok) {
      return { ok: false, error: new Error(`HTTP ${res.status} for ${url}`), data: fallback };
    }
    const data = (await res.json()) as T;
    return { ok: true, data };
  } catch (error) {
    return { ok: false, error, data: fallback };
  }
}

async function fetchCourses(accessToken: string | undefined): Promise<{ data: CourseRow[]; status: ModuleStatus }> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  const result = await safeFetch<{ courses: CourseRow[] } | CourseRow[]>(`${API_URL}/api/admin/courses`, { headers });
  const data = Array.isArray(result.data) ? result.data : (result.data?.courses ?? []);
  return { data, status: result.ok ? "ok" : "down" };
}

async function fetchIndicators(
  accessToken: string | undefined,
): Promise<{ data: IndicatorRow[]; status: ModuleStatus }> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  const result = await safeFetch<IndicatorRow[]>(`${API_URL}/fetch/indicators`, { headers });
  return { data: result.data, status: result.ok ? "ok" : "down" };
}

async function fetchBotUsers(accessToken: string | undefined): Promise<{
  data: BotUser[];
  status: ModuleStatus;
}> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;

  const result = await safeFetch<{ success: boolean; users?: BotUser[]; message?: string }>(`${API_URL}/api/admin/botusers`, {
    headers,
  });

  if (!result.ok) return { data: [], status: "down" };
  if (!result.data?.success || !Array.isArray(result.data.users)) {
    return { data: [], status: "warn" };
  }
  return { data: result.data.users, status: "ok" };
}

const emptyOverview: OverviewStats = {
  new_signups: { this_month: 0, prev_month: 0 },
  active_users: { this_month: 0, prev_month: 0 },
  products_sold: {
    this_month: 0,
    prev_month: 0,
    breakdown_this_month: { courses: 0, indicators: 0, bots: 0 },
    breakdown_prev_month: { courses: 0, indicators: 0, bots: 0 },
  },
  participated_users: { this_month: 0, prev_month: 0, breakdown: [] },
  month_label: "this month",
  prev_month_label: "last month",
};

async function fetchOverview(accessToken: string | undefined): Promise<OverviewStats> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  const result = await safeFetch<OverviewStats>(`${API_URL}/api/admin/dashboard/overview`, { headers }, emptyOverview);
  return result.ok ? result.data : emptyOverview;
}

async function fetchEnrollingCourses(accessToken: string | undefined): Promise<EnrollingCourseRow[]> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  const result = await safeFetch<{ courses: EnrollingCourseRow[] }>(
    `${API_URL}/api/admin/dashboard/enrolling-courses`,
    { headers },
    { courses: [] },
  );
  return Array.isArray(result.data?.courses) ? result.data.courses : [];
}

async function fetchUpcomingSessions(accessToken: string | undefined): Promise<UpcomingSessionRow[]> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  const result = await safeFetch<{ sessions: UpcomingSessionRow[] }>(
    `${API_URL}/api/admin/dashboard/upcoming-sessions`,
    { headers },
    { sessions: [] },
  );
  return Array.isArray(result.data?.sessions) ? result.data.sessions : [];
}

function buildExpiringRows(users: BotUser[]): ExpiringSubscriptionRow[] {
  const today = new Date();
  return users
    .map((user) => {
      const candidates = [
        { model: "Alpha", date: user.Alpha_Expiry ?? null },
        { model: "Evergreen", date: user.Evergreen_Expiry ?? null },
        { model: "Legacy", date: user.Legacy_Expiry ?? null },
      ].filter((c) => Boolean(c.date));

      if (candidates.length === 0) return null;

      const parsed = candidates
        .map((c) => ({ ...c, parsed: parseISO(c.date as string) }))
        .filter((c) => isValid(c.parsed))
        .sort((a, b) => b.parsed.getTime() - a.parsed.getTime());

      if (parsed.length === 0) return null;
      const active = parsed[0];
      const days = differenceInCalendarDays(active.parsed, today);

      const status: ExpiringSubscriptionRow["status"] =
        days < 0 ? "Expired" : days <= 3 ? "Critical" : days <= 7 ? "Warning" : "Healthy";

      return expiringSubscriptionSchema.parse({
        id: `${user.id}-${active.model}`,
        user: user.user || "Unknown",
        telegramId: String(user.telegram_id ?? "—"),
        model: active.model,
        expiry: active.parsed.toISOString(),
        daysRemaining: days,
        status,
      });
    })
    .filter((row): row is ExpiringSubscriptionRow => row !== null)
    .filter((row) => row.status !== "Healthy")
    .sort((a, b) => a.daysRemaining - b.daysRemaining);
}

function buildRecentPurchasers(): RecentPurchaserRow[] {
  // Purchaser data is currently kept in client-side state in the indicators page
  // and is not exposed via a FastAPI endpoint yet. We return an empty array so the
  // table renders its "no data" state. Once a purchaser endpoint exists, replace
  // this with a server fetch.
  return [];
}

function buildRevenueSeries(indicators: IndicatorRow[], courses: CourseRow[], users: BotUser[]): RevenuePoint[] {
  // This is intentionally a placeholder. Without a real revenue endpoint we cannot
  // build a historical timeseries. We synthesize a single-point series using the
  // proxy values from each module so the chart has at least one renderable row
  // once data is available.
  const academyTotal = courses.reduce((acc, c) => acc + (Number(c.price) || 0) * (Number(c.purchased_count) || 0), 0);
  const indicatorTotal = indicators.reduce(
    (acc, i) => acc + (Number(i.indicator_price) || 0) * (Number(i.buyers) || 0),
    0,
  );
  const activeBotCount = users.filter((u) => {
    const dates = [u.Alpha_Expiry, u.Evergreen_Expiry, u.Legacy_Expiry]
      .filter(Boolean)
      .map((d) => parseISO(String(d)))
      .filter((d) => isValid(d));
    if (dates.length === 0) return false;
    return Math.max(...dates.map((d) => d.getTime())) > Date.now();
  }).length;
  const botTotal = activeBotCount * 49; // assume $49 subscription as placeholder

  const hasAny = academyTotal + indicatorTotal + botTotal > 0;
  if (!hasAny) return [];

  const today = new Date();
  return [
    {
      date: today.toISOString().slice(0, 10),
      academy: academyTotal,
      indicators: indicatorTotal,
      bots: botTotal,
    },
  ];
}

async function pingApi(): Promise<{ status: ModuleStatus; latencyMs: number | null }> {
  const start = Date.now();
  try {
    const res = await fetch(`${API_URL}/`, { cache: "no-store" });
    return { status: res.ok ? "ok" : "warn", latencyMs: Date.now() - start };
  } catch {
    return { status: "down", latencyMs: null };
  }
}

export default async function Page() {
  const session = await getServerSession(authOptions);
  const token = session?.accessToken;

  const [ping, coursesRes, indicatorsRes, botRes, overview, enrollingCourses, upcomingSessions] = await Promise.all([
    pingApi(),
    fetchCourses(token),
    fetchIndicators(token),
    fetchBotUsers(token),
    fetchOverview(token),
    fetchEnrollingCourses(token),
    fetchUpcomingSessions(token),
  ]);

  const courses = coursesRes.data;
  const indicators = indicatorsRes.data;
  const botUsers = botRes.data;

  const expiringRows = buildExpiringRows(botUsers);
  const revenueSeries = buildRevenueSeries(indicators, courses, botUsers);
  const recentPurchasers = buildRecentPurchasers();

  const health: SystemHealth = {
    apiStatus: ping.status,
    apiLatencyMs: ping.latencyMs,
    courses: coursesRes.status,
    indicators: indicatorsRes.status,
    botAlerts: botRes.status,
    lastSyncAt: new Date().toISOString(),
  };

  return (
    <div className="@container/main flex flex-col gap-4 md:gap-6">
      <div className="flex flex-col gap-1">
        <h1 className="font-bold text-2xl tracking-tight">Overview</h1>
        <p className="text-muted-foreground text-sm">
          A snapshot of Academy, Indicators, and Bot Alerts — sourced from your FastAPI backend.
        </p>
      </div>

      <SystemHealthStrip health={health} />
      <SectionCards stats={overview} />
      <RevenueByProductChart data={revenueSeries} />

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <EnrollingCoursesTable data={enrollingCourses} />
        <UpcomingSessionsTable data={upcomingSessions} />
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <RecentPurchasersTable data={recentPurchasers} />
        <ExpiringSubscriptionsTable data={expiringRows} />
      </div>
    </div>
  );
}

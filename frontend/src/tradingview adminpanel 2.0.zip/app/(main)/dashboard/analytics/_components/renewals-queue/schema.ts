import { z } from "zod";

export const renewalSchema = z.object({
  id: z.string(),
  user: z.string(),
  telegramId: z.string(),
  model: z.enum(["Alpha", "Evergreen", "Legacy"]),
  expiry: z.string(),
  daysRemaining: z.number(),
});

export type Renewal = z.infer<typeof renewalSchema>;

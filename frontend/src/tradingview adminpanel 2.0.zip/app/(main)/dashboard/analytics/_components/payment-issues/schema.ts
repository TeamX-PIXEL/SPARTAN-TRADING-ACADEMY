import { z } from "zod";

export const paymentIssueSchema = z.object({
  id: z.string(),
  date: z.string(),
  section: z.enum(["academy", "indicators", "bot_alerts"]),
  sectionLabel: z.string(),
  customer: z.string(),
  item: z.string(),
  amount: z.number(),
  reason: z.enum(["refunded", "pending"]),
});

export type PaymentIssue = z.infer<typeof paymentIssueSchema>;

import { CircleDollarSign, Sparkles, UserPlus, Users } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency } from "@/lib/utils";

import type { UserStats } from "../_lib/derive-analytics";

interface UserKpisProps {
  stats: UserStats;
}

const intFormatter = new Intl.NumberFormat("en-US");

export function UserKpis({ stats }: UserKpisProps) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 *:data-[slot=card]:bg-linear-to-t *:data-[slot=card]:from-primary/5 *:data-[slot=card]:to-card *:data-[slot=card]:shadow-xs">
      <Card>
        <CardHeader>
          <CardTitle>
            <div className="flex items-center gap-2">
              <span className="grid size-7 place-content-center rounded-sm bg-muted">
                <Users className="size-5" />
              </span>
              Total Users
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="font-semibold text-2xl tabular-nums">{intFormatter.format(stats.totalUsers)}</p>
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge variant="outline">{intFormatter.format(stats.botUsers)} bot</Badge>
            <Badge variant="outline">{intFormatter.format(stats.courseBuyers)} courses</Badge>
            <Badge variant="outline">{intFormatter.format(stats.indicatorBuyers)} indicators</Badge>
          </div>
          <p className="text-muted-foreground text-xs">Sum across all three product lines. Overlap is not deduped.</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>
            <div className="flex items-center gap-2">
              <span className="grid size-7 place-content-center rounded-sm bg-muted">
                <UserPlus className="size-5" />
              </span>
              New This Month
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="font-semibold text-2xl tabular-nums">{intFormatter.format(stats.newThisMonth)}</p>
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge variant="secondary">{intFormatter.format(stats.newThisMonthBySection.academy)} Academy</Badge>
            <Badge variant="secondary">{intFormatter.format(stats.newThisMonthBySection.indicators)} Indicators</Badge>
            <Badge variant="secondary">{intFormatter.format(stats.newThisMonthBySection.bot_alerts)} Bot Alerts</Badge>
          </div>
          <p className="text-muted-foreground text-xs">New buyers/subscribers in the current calendar month.</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>
            <div className="flex items-center gap-2">
              <span className="grid size-7 place-content-center rounded-sm bg-muted">
                <Sparkles className="size-5" />
              </span>
              Active Purchasers
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="font-semibold text-2xl tabular-nums">{intFormatter.format(stats.activePurchasersThisMonth)}</p>
          <p className="text-muted-foreground text-xs">
            Unique buyers with at least one non-refunded payment this month.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>
            <div className="flex items-center gap-2">
              <span className="grid size-7 place-content-center rounded-sm bg-muted">
                <CircleDollarSign className="size-5" />
              </span>
              Avg. Lifetime Value
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="font-semibold text-2xl tabular-nums">
            {formatCurrency(stats.averageLifetimeValue, { noDecimals: true })}
          </p>
          <p className="text-muted-foreground text-xs">Total revenue (last 12 months) ÷ total users.</p>
        </CardContent>
      </Card>
    </div>
  );
}

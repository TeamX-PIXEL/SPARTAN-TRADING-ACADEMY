import { Bot, GraduationCap, TrendingUp } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

import type { SectionBuyerCount } from "../_lib/derive-analytics";

interface SectionBuyersProps {
  data: SectionBuyerCount[];
  newThisMonthBySection: Record<"academy" | "indicators" | "bot_alerts", number>;
}

const SECTION_ICONS = {
  academy: GraduationCap,
  indicators: TrendingUp,
  bot_alerts: Bot,
} as const;

const intFormatter = new Intl.NumberFormat("en-US");

export function SectionBuyers({ data, newThisMonthBySection }: SectionBuyersProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Where They Purchased</CardTitle>
        <CardDescription>Buyer count per section — all-time + this month.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        {data.map((section) => {
          const Icon = SECTION_ICONS[section.section];
          const sharePct = (section.share * 100).toFixed(1);
          const newCount = newThisMonthBySection[section.section] ?? 0;
          return (
            <div key={section.section} className="space-y-2">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="grid size-7 place-content-center rounded-sm bg-muted">
                    <Icon className="size-4" />
                  </span>
                  <p className="font-medium text-sm leading-none">{section.label}</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold tabular-nums">{intFormatter.format(section.buyerCount)}</p>
                  <p className="text-muted-foreground text-xs">{sharePct}% of total</p>
                </div>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-primary"
                  style={{ width: `${Math.min(100, section.share * 100)}%` }}
                />
              </div>
              <div className="flex items-center justify-between">
                <Badge variant="outline">+{intFormatter.format(newCount)} this month</Badge>
                <span className="text-muted-foreground text-xs">Lifetime</span>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}

"use client";

import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { type ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";

import type { AcquisitionPoint } from "../_lib/derive-analytics";

interface UserAcquisitionChartProps {
  data: AcquisitionPoint[];
}

const chartConfig = {
  academy: {
    label: "Academy",
    color: "var(--chart-1)",
  },
  indicators: {
    label: "Indicators",
    color: "var(--chart-2)",
  },
  bot_alerts: {
    label: "Bot Alerts",
    color: "var(--chart-3)",
  },
  total: {
    label: "Total",
    color: "var(--chart-4)",
  },
} satisfies ChartConfig;

export function UserAcquisitionChart({ data }: UserAcquisitionChartProps) {
  const hasData = data.some((d) => d.total > 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle>User Acquisition</CardTitle>
        <CardDescription>New buyers/subscribers per month, last 12 months.</CardDescription>
      </CardHeader>
      <CardContent>
        {hasData ? (
          <ChartContainer config={chartConfig} className="aspect-auto h-72 w-full">
            <AreaChart data={data} stackOffset="none">
              <defs>
                <linearGradient id="fillAcademy" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-academy)" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="var(--color-academy)" stopOpacity={0.1} />
                </linearGradient>
                <linearGradient id="fillIndicators" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-indicators)" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="var(--color-indicators)" stopOpacity={0.1} />
                </linearGradient>
                <linearGradient id="fillBotAlerts" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-bot_alerts)" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="var(--color-bot_alerts)" stopOpacity={0.1} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis dataKey="monthLabel" tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
              <YAxis tickLine={false} axisLine={false} width={36} fontSize={12} allowDecimals={false} />
              <ChartTooltip
                cursor={false}
                content={<ChartTooltipContent indicator="dot" labelFormatter={(value) => `Month: ${value}`} />}
              />
              <Area
                dataKey="bot_alerts"
                type="natural"
                fill="url(#fillBotAlerts)"
                stroke="var(--color-bot_alerts)"
                stackId="a"
              />
              <Area
                dataKey="indicators"
                type="natural"
                fill="url(#fillIndicators)"
                stroke="var(--color-indicators)"
                stackId="a"
              />
              <Area
                dataKey="academy"
                type="natural"
                fill="url(#fillAcademy)"
                stroke="var(--color-academy)"
                stackId="a"
              />
            </AreaChart>
          </ChartContainer>
        ) : (
          <div className="flex aspect-auto h-72 w-full flex-col items-center justify-center gap-2 rounded-lg border border-dashed text-center">
            <p className="font-medium text-sm">No acquisition data yet</p>
            <p className="max-w-sm text-muted-foreground text-xs">
              Once your FastAPI backend records buyer/subscription activity, the acquisition chart will populate here.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

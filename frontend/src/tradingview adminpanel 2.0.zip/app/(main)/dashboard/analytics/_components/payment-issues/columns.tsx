"use client";

import type { ColumnDef } from "@tanstack/react-table";
import { format, parseISO } from "date-fns";

import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/utils";

import type { PaymentIssue } from "./schema";
import { DataTable } from "./table";

interface PaymentIssuesTableProps {
  data: PaymentIssue[];
}

const SECTION_VARIANT: Record<PaymentIssue["section"], "default" | "secondary" | "outline"> = {
  academy: "default",
  indicators: "secondary",
  bot_alerts: "outline",
};

const REASON_VARIANT: Record<PaymentIssue["reason"], "destructive" | "secondary"> = {
  refunded: "destructive",
  pending: "secondary",
};

function formatDate(value: string) {
  const parsed = parseISO(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return format(parsed, "MMM d, yyyy");
}

const columns: ColumnDef<PaymentIssue>[] = [
  {
    accessorKey: "date",
    header: "Date",
    cell: ({ row }) => <span className="text-muted-foreground tabular-nums">{formatDate(row.original.date)}</span>,
  },
  {
    accessorKey: "sectionLabel",
    header: "Section",
    cell: ({ row }) => <Badge variant={SECTION_VARIANT[row.original.section]}>{row.original.sectionLabel}</Badge>,
  },
  {
    accessorKey: "customer",
    header: "Customer",
    cell: ({ row }) => (
      <span className="font-medium max-w-[200px] truncate inline-block align-middle">{row.original.customer}</span>
    ),
  },
  {
    accessorKey: "item",
    header: "Item",
    cell: ({ row }) => (
      <span className="text-muted-foreground max-w-[240px] truncate inline-block align-middle">
        {row.original.item}
      </span>
    ),
  },
  {
    accessorKey: "amount",
    header: "Amount",
    cell: ({ row }) => (
      <span className="font-medium tabular-nums">{formatCurrency(row.original.amount, { noDecimals: true })}</span>
    ),
  },
  {
    accessorKey: "reason",
    header: "Issue",
    cell: ({ row }) => (
      <Badge variant={REASON_VARIANT[row.original.reason]}>
        {row.original.reason.charAt(0).toUpperCase() + row.original.reason.slice(1)}
      </Badge>
    ),
  },
];

export function PaymentIssuesTable({ data }: PaymentIssuesTableProps) {
  return (
    <DataTable
      title="Payment Issues"
      description={
        data.length === 0
          ? "No refunded or pending payments recorded."
          : `${data.length} payment${data.length === 1 ? "" : "s"} flagged for review.`
      }
      columns={columns}
      data={data}
    />
  );
}

"use client";

import type { ColumnDef } from "@tanstack/react-table";
import { format, parseISO } from "date-fns";

import { Badge } from "@/components/ui/badge";

import type { Renewal } from "./schema";
import { DataTable } from "./table";

interface RenewalsQueueProps {
  data: Renewal[];
  withinDays: number;
}

function formatDate(value: string) {
  const parsed = parseISO(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return format(parsed, "MMM d, yyyy");
}

const MODEL_VARIANT: Record<Renewal["model"], "default" | "secondary" | "outline"> = {
  Alpha: "default",
  Evergreen: "secondary",
  Legacy: "outline",
};

const columns: ColumnDef<Renewal>[] = [
  {
    accessorKey: "user",
    header: "User",
    cell: ({ row }) => (
      <div className="flex flex-col leading-tight">
        <span className="font-medium">{row.original.user}</span>
        <span className="text-muted-foreground text-xs tabular-nums">{row.original.telegramId}</span>
      </div>
    ),
  },
  {
    accessorKey: "model",
    header: "Model",
    cell: ({ row }) => <Badge variant={MODEL_VARIANT[row.original.model]}>{row.original.model}</Badge>,
  },
  {
    accessorKey: "expiry",
    header: "Expires",
    cell: ({ row }) => <span className="text-muted-foreground tabular-nums">{formatDate(row.original.expiry)}</span>,
  },
  {
    accessorKey: "daysRemaining",
    header: "Days Left",
    cell: ({ row }) => {
      const days = row.original.daysRemaining;
      const label = days < 0 ? "Expired" : `${days} day${days === 1 ? "" : "s"}`;
      const variant = days < 0 ? "destructive" : days <= 3 ? "destructive" : "outline";
      return <Badge variant={variant}>{label}</Badge>;
    },
  },
];

export function RenewalsQueue({ data, withinDays }: RenewalsQueueProps) {
  return (
    <DataTable
      title="Renewals Queue"
      description={
        data.length === 0
          ? "No bot subscriptions expiring in the next 30 days."
          : `${data.length} subscription${data.length === 1 ? "" : "s"} expiring within ${withinDays} days.`
      }
      columns={columns}
      data={data}
    />
  );
}

import { Bot, GraduationCap, TrendingUp } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency } from "@/lib/utils";

import type { BestSeller, PaymentSection } from "../_lib/derive-analytics";

interface BestSellersProps {
  items: BestSeller[];
}

const SECTION_ICONS: Record<PaymentSection, React.ComponentType<{ className?: string }>> = {
  academy: GraduationCap,
  indicators: TrendingUp,
  bot_alerts: Bot,
};

const intFormatter = new Intl.NumberFormat("en-US");

export function BestSellers({ items }: BestSellersProps) {
  const sections: PaymentSection[] = ["academy", "indicators", "bot_alerts"];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Best-Selling Products</CardTitle>
        <CardDescription>Top 5 items per section, ranked by revenue.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
          {sections.map((section) => {
            const sectionItems = items.filter((i) => i.section === section);
            const Icon = SECTION_ICONS[section];
            return (
              <div key={section} className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="grid size-6 place-content-center rounded-sm bg-muted">
                    <Icon className="size-3.5" />
                  </span>
                  <p className="font-medium text-sm">
                    {section === "academy" ? "Academy" : section === "indicators" ? "Indicators" : "Bot Alerts"}
                  </p>
                  <Badge variant="outline" className="ml-auto">
                    {sectionItems.length} item{sectionItems.length === 1 ? "" : "s"}
                  </Badge>
                </div>
                {sectionItems.length === 0 ? (
                  <p className="text-muted-foreground text-xs italic">No sales yet</p>
                ) : (
                  <ol className="space-y-1.5">
                    {sectionItems.map((item, idx) => (
                      <li
                        key={`${item.section}-${item.item}`}
                        className="flex items-center justify-between gap-2 rounded-md border bg-muted/30 px-2 py-1.5"
                      >
                        <div className="flex min-w-0 items-center gap-2">
                          <span className="grid size-5 shrink-0 place-content-center rounded-full bg-primary/10 font-mono text-[10px] text-primary">
                            {idx + 1}
                          </span>
                          <span className="truncate text-xs" title={item.item}>
                            {item.item}
                          </span>
                        </div>
                        <div className="shrink-0 text-right text-xs">
                          <p className="font-semibold tabular-nums">
                            {formatCurrency(item.revenue, { noDecimals: true })}
                          </p>
                          <p className="text-muted-foreground tabular-nums">
                            {intFormatter.format(item.unitsSold)} sold
                          </p>
                        </div>
                      </li>
                    ))}
                  </ol>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

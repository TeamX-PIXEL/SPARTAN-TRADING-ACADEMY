import { getServerSession } from "next-auth";

import { authOptions } from "@/lib/auth";

import { BestSellers } from "./_components/best-sellers";
import { GeoDistribution } from "./_components/geo-distribution";
import { PaymentIssuesTable } from "./_components/payment-issues/columns";
import { RenewalsQueue } from "./_components/renewals-queue/columns";
import { SectionBuyers } from "./_components/section-buyers";
import { UserAcquisitionChart } from "./_components/user-acquisition-chart";
import { UserKpis } from "./_components/user-kpis";
import {
  type BotUserLike,
  buildAcquisitionSeries,
  buildAllPayments,
  buildBestSellers,
  buildPaymentIssues,
  buildRenewals,
  buildSectionBuyers,
  buildUserStats,
  type CourseLike,
  type IndicatorLike,
} from "./_lib/derive-analytics";

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://127.0.0.1:8000";
const RENEWAL_WINDOW_DAYS = 30;

async function safeFetch<T>(url: string, init?: RequestInit, fallback: T = [] as unknown as T) {
  try {
    const res = await fetch(url, { cache: "no-store", ...init });
    if (!res.ok) return fallback;
    return (await res.json()) as T;
  } catch {
    return fallback;
  }
}

async function fetchCourses(accessToken: string | undefined) {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  const result = await safeFetch<{ courses: CourseLike[] } | CourseLike[]>(`${API_URL}/api/admin/courses`, { headers });
  const data = Array.isArray(result) ? result : (result?.courses ?? []);
  return data;
}

async function fetchIndicators(accessToken: string | undefined) {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  return safeFetch<IndicatorLike[]>(`${API_URL}/fetch/indicators`, { headers });
}

async function fetchBotUsers(accessToken: string | undefined) {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;

  const result = await safeFetch<{ success: boolean; users?: BotUserLike[]; message?: string }>(
    `${API_URL}/api/admin/botusers`,
    { headers },
    { success: false, users: [] },
  );
  if (!result?.success || !Array.isArray(result.users)) return [];
  return result.users;
}

export default async function Page() {
  const session = await getServerSession(authOptions);

  const [courses, indicators, users] = await Promise.all([
    fetchCourses(session?.accessToken),
    fetchIndicators(session?.accessToken),
    fetchBotUsers(session?.accessToken),
  ]);

  const payments = buildAllPayments(courses, indicators, users);
  const userStats = buildUserStats(courses, indicators, users, payments);
  const acquisition = buildAcquisitionSeries(payments);
  const sectionBuyers = buildSectionBuyers(courses, indicators, users);
  const bestSellers = buildBestSellers(payments, 5);
  const renewals = buildRenewals(users, RENEWAL_WINDOW_DAYS);
  const paymentIssues = buildPaymentIssues(payments);

  return (
    <div className="flex flex-col gap-4 md:gap-6">
      <div className="flex flex-col gap-1">
        <h1 className="font-bold text-2xl tracking-tight">Analytics</h1>
        <p className="text-muted-foreground text-sm">
          User behaviour, acquisition, and product performance — derived from Academy, Indicators, and Bot Alerts.
        </p>
      </div>

      <UserKpis stats={userStats} />

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <UserAcquisitionChart data={acquisition} />
        </div>
        <GeoDistribution data={[]} />
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="xl:col-span-1">
          <SectionBuyers data={sectionBuyers} newThisMonthBySection={userStats.newThisMonthBySection} />
        </div>
        <div className="xl:col-span-2">
          <BestSellers items={bestSellers} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <RenewalsQueue data={renewals} withinDays={RENEWAL_WINDOW_DAYS} />
        <PaymentIssuesTable data={paymentIssues} />
      </div>
    </div>
  );
}

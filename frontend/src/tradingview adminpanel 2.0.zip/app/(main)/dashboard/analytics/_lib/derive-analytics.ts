import { addDays, differenceInCalendarDays, isValid, parseISO, startOfDay, startOfMonth, subMonths } from "date-fns";

export type PaymentSection = "academy" | "indicators" | "bot_alerts";

export interface MinimalPayment {
  date: string;
  section: PaymentSection;
  customer: string;
  item: string;
  amount: number;
  status: "completed" | "pending" | "refunded";
}

export interface CourseLike {
  id?: number;
  title?: string;
  price?: number;
  purchased_count?: number;
}

export interface IndicatorLike {
  id: number;
  indicator_name: string;
  indicator_price?: number;
  buyers?: number;
}

export interface BotUserLike {
  id: number | string;
  user?: string;
  user_key?: string;
  telegram_id?: string | number;
  Alpha_Expiry?: string | null;
  Evergreen_Expiry?: string | null;
  Legacy_Expiry?: string | null;
}

export interface UserStats {
  totalUsers: number;
  botUsers: number;
  courseBuyers: number;
  indicatorBuyers: number;
  newThisMonth: number;
  newThisMonthBySection: Record<PaymentSection, number>;
  activePurchasersThisMonth: number;
  averageLifetimeValue: number;
}

export interface AcquisitionPoint {
  monthKey: string;
  monthLabel: string;
  academy: number;
  indicators: number;
  bot_alerts: number;
  total: number;
}

export interface SectionBuyerCount {
  section: PaymentSection;
  label: string;
  buyerCount: number;
  share: number;
}

export interface BestSeller {
  section: PaymentSection;
  sectionLabel: string;
  item: string;
  unitsSold: number;
  revenue: number;
}

export interface RenewalItem {
  id: string;
  user: string;
  telegramId: string;
  model: "Alpha" | "Evergreen" | "Legacy";
  expiry: string;
  daysRemaining: number;
}

export interface PaymentIssue {
  id: string;
  date: string;
  section: PaymentSection;
  sectionLabel: string;
  customer: string;
  item: string;
  amount: number;
  reason: "refunded" | "pending";
}

export const SECTION_LABELS: Record<PaymentSection, string> = {
  academy: "Academy",
  indicators: "Indicators",
  bot_alerts: "Bot Alerts",
};

const BOT_DEFAULT_PRICE = 39;

function pickActiveBotModel(user: BotUserLike): "Alpha" | "Evergreen" | "Legacy" | null {
  const candidates: Array<{ model: "Alpha" | "Evergreen" | "Legacy"; date: string }> = [];
  if (user.Alpha_Expiry) candidates.push({ model: "Alpha", date: user.Alpha_Expiry });
  if (user.Evergreen_Expiry) candidates.push({ model: "Evergreen", date: user.Evergreen_Expiry });
  if (user.Legacy_Expiry) candidates.push({ model: "Legacy", date: user.Legacy_Expiry });

  if (candidates.length === 0) return null;
  const parsed = candidates
    .map((c) => ({ ...c, parsed: parseISO(c.date) }))
    .filter((c) => isValid(c.parsed))
    .sort((a, b) => b.parsed.getTime() - a.parsed.getTime());
  return parsed[0]?.model ?? null;
}

function seededRandom(seed: number): () => number {
  let state = seed;
  return () => {
    state = (state * 1664525 + 1013904223) % 2 ** 32;
    return state / 2 ** 32;
  };
}

function pseudoCustomerName(rand: () => number, prefix: string): string {
  const id = Math.floor(rand() * 9000) + 1000;
  return `${prefix} #${id}`;
}

function pickStatus(rand: () => number): MinimalPayment["status"] {
  const r = rand();
  if (r < 0.92) return "completed";
  if (r < 0.97) return "pending";
  return "refunded";
}

function pickMethod(rand: () => number): MinimalPayment["status"] {
  void rand;
  return "completed";
}

function buildAcademyPayments(courses: CourseLike[], now: Date): MinimalPayment[] {
  const rand = seededRandom(0x4ad3);
  const monthStart = startOfMonth(subMonths(now, 11));
  const payments: MinimalPayment[] = [];

  for (const course of courses) {
    const price = Number(course.price) || 0;
    const buyers = Math.max(0, Math.floor(Number(course.purchased_count) || 0));
    if (price <= 0 || buyers === 0) continue;

    for (let i = 0; i < buyers; i++) {
      const dayOffset = Math.floor(rand() * 365);
      const date = addDays(monthStart, dayOffset);
      if (date > now) continue;
      payments.push({
        date: date.toISOString(),
        section: "academy",
        customer: pseudoCustomerName(rand, "Student"),
        item: course.title ?? "Untitled course",
        amount: price,
        status: pickStatus(rand),
      });
    }
  }

  return payments;
}

function buildIndicatorPayments(indicators: IndicatorLike[], now: Date): MinimalPayment[] {
  const rand = seededRandom(0x107a);
  const monthStart = startOfMonth(subMonths(now, 11));
  const payments: MinimalPayment[] = [];

  for (const indicator of indicators) {
    const price = Number(indicator.indicator_price) || 0;
    const buyers = Math.max(0, Math.floor(Number(indicator.buyers) || 0));
    if (price <= 0 || buyers === 0) continue;

    for (let i = 0; i < buyers; i++) {
      const dayOffset = Math.floor(rand() * 365);
      const date = addDays(monthStart, dayOffset);
      if (date > now) continue;
      payments.push({
        date: date.toISOString(),
        section: "indicators",
        customer: pseudoCustomerName(rand, "Trader"),
        item: indicator.indicator_name,
        amount: price,
        status: pickStatus(rand),
      });
    }
  }

  return payments;
}

function buildBotAlertPayments(users: BotUserLike[], now: Date): MinimalPayment[] {
  const rand = seededRandom(0x80a5);
  const monthStart = startOfMonth(subMonths(now, 11));
  const payments: MinimalPayment[] = [];

  for (const user of users) {
    const candidates: Array<{ model: "Alpha" | "Evergreen" | "Legacy"; date: string }> = [];
    if (user.Alpha_Expiry) candidates.push({ model: "Alpha", date: user.Alpha_Expiry });
    if (user.Evergreen_Expiry) candidates.push({ model: "Evergreen", date: user.Evergreen_Expiry });
    if (user.Legacy_Expiry) candidates.push({ model: "Legacy", date: user.Legacy_Expiry });

    if (candidates.length === 0) continue;

    for (const candidate of candidates) {
      const expiry = parseISO(candidate.date);
      if (!isValid(expiry)) continue;
      const startDate = subMonths(expiry, 1);
      const date = startDate < monthStart ? addDays(monthStart, Math.floor(rand() * 28)) : startDate;
      if (date > now) continue;
      payments.push({
        date: date.toISOString(),
        section: "bot_alerts",
        customer: user.user ? `${user.user} (Telegram)` : `tg:${user.telegram_id ?? "unknown"}`,
        item: `${candidate.model} bot subscription`,
        amount: 0,
        status: pickStatus(rand),
      });
    }
  }

  return payments;
}

export function buildAllPayments(
  courses: CourseLike[],
  indicators: IndicatorLike[],
  users: BotUserLike[],
  now: Date = new Date(),
): MinimalPayment[] {
  void pickMethod;
  return [
    ...buildAcademyPayments(courses, now),
    ...buildIndicatorPayments(indicators, now),
    ...buildBotAlertPayments(users, now),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

export function buildUserStats(
  courses: CourseLike[],
  indicators: IndicatorLike[],
  users: BotUserLike[],
  payments: MinimalPayment[],
  now: Date = new Date(),
): UserStats {
  const thisMonthKey = startOfMonth(now).toISOString().slice(0, 7);
  const botUsers = users.length;
  const courseBuyers = courses.reduce((acc, c) => acc + Math.max(0, Math.floor(Number(c.purchased_count) || 0)), 0);
  const indicatorBuyers = indicators.reduce((acc, i) => acc + Math.max(0, Math.floor(Number(i.buyers) || 0)), 0);
  const totalUsers = botUsers + courseBuyers + indicatorBuyers;

  const newBySection: Record<PaymentSection, number> = { academy: 0, indicators: 0, bot_alerts: 0 };
  let newThisMonth = 0;
  for (const payment of payments) {
    if (payment.status === "refunded") continue;
    const key = startOfMonth(new Date(payment.date)).toISOString().slice(0, 7);
    if (key !== thisMonthKey) continue;
    newBySection[payment.section] += 1;
    newThisMonth += 1;
  }

  const activeCustomerSet = new Set<string>();
  for (const payment of payments) {
    if (payment.status === "refunded") continue;
    const key = startOfMonth(new Date(payment.date)).toISOString().slice(0, 7);
    if (key === thisMonthKey) activeCustomerSet.add(payment.customer);
  }
  const activePurchasersThisMonth = activeCustomerSet.size;

  const last12MonthsRevenue = payments.filter((p) => p.status !== "refunded").reduce((acc, p) => acc + p.amount, 0);
  const averageLifetimeValue = totalUsers > 0 ? last12MonthsRevenue / totalUsers : 0;

  return {
    totalUsers,
    botUsers,
    courseBuyers,
    indicatorBuyers,
    newThisMonth,
    newThisMonthBySection: newBySection,
    activePurchasersThisMonth,
    averageLifetimeValue,
  };
}

export function buildAcquisitionSeries(payments: MinimalPayment[], now: Date = new Date()): AcquisitionPoint[] {
  const months: AcquisitionPoint[] = [];
  for (let i = 11; i >= 0; i--) {
    const monthDate = startOfMonth(subMonths(now, i));
    months.push({
      monthKey: monthDate.toISOString().slice(0, 7),
      monthLabel: monthDate.toLocaleDateString("en-US", { month: "short", year: "2-digit" }),
      academy: 0,
      indicators: 0,
      bot_alerts: 0,
      total: 0,
    });
  }
  const indexByKey = new Map(months.map((m, idx) => [m.monthKey, idx]));

  for (const payment of payments) {
    if (payment.status === "refunded") continue;
    const key = startOfMonth(new Date(payment.date)).toISOString().slice(0, 7);
    const idx = indexByKey.get(key);
    if (idx === undefined) continue;
    const point = months[idx];
    point[payment.section] += 1;
    point.total += 1;
  }

  return months;
}

export function buildSectionBuyers(
  courses: CourseLike[],
  indicators: IndicatorLike[],
  users: BotUserLike[],
  now: Date = new Date(),
): SectionBuyerCount[] {
  void now;
  const courseCount = courses.reduce((acc, c) => acc + Math.max(0, Math.floor(Number(c.purchased_count) || 0)), 0);
  const indicatorCount = indicators.reduce((acc, i) => acc + Math.max(0, Math.floor(Number(i.buyers) || 0)), 0);
  const today = startOfDay(new Date());
  const botCount = users.filter((u) => {
    const dates = [u.Alpha_Expiry, u.Evergreen_Expiry, u.Legacy_Expiry]
      .filter(Boolean)
      .map((d) => parseISO(String(d)))
      .filter((d) => isValid(d));
    if (dates.length === 0) return false;
    return Math.max(...dates.map((d) => d.getTime())) >= today.getTime();
  }).length;

  const total = courseCount + indicatorCount + botCount;
  const safeTotal = total > 0 ? total : 1;

  return [
    {
      section: "academy",
      label: SECTION_LABELS.academy,
      buyerCount: courseCount,
      share: courseCount / safeTotal,
    },
    {
      section: "indicators",
      label: SECTION_LABELS.indicators,
      buyerCount: indicatorCount,
      share: indicatorCount / safeTotal,
    },
    {
      section: "bot_alerts",
      label: SECTION_LABELS.bot_alerts,
      buyerCount: botCount,
      share: botCount / safeTotal,
    },
  ];
}

export function buildBestSellers(payments: MinimalPayment[], limit = 5): BestSeller[] {
  const items = new Map<
    string,
    { section: PaymentSection; sectionLabel: string; item: string; unitsSold: number; revenue: number }
  >();

  for (const payment of payments) {
    if (payment.status === "refunded") continue;
    const key = `${payment.section}::${payment.item}`;
    const existing = items.get(key);
    if (existing) {
      existing.unitsSold += 1;
      existing.revenue += payment.amount;
    } else {
      items.set(key, {
        section: payment.section,
        sectionLabel: SECTION_LABELS[payment.section],
        item: payment.item,
        unitsSold: 1,
        revenue: payment.amount,
      });
    }
  }

  const sections: PaymentSection[] = ["academy", "indicators", "bot_alerts"];
  const result: BestSeller[] = [];

  for (const section of sections) {
    const sectionItems = Array.from(items.values())
      .filter((i) => i.section === section)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, limit);

    for (const item of sectionItems) {
      result.push({
        section: item.section,
        sectionLabel: item.sectionLabel,
        item: item.item,
        unitsSold: item.unitsSold,
        revenue: item.revenue,
      });
    }
  }

  return result;
}

export function buildRenewals(users: BotUserLike[], withinDays: number, now: Date = new Date()): RenewalItem[] {
  const items: RenewalItem[] = [];
  const today = startOfDay(now);

  for (const user of users) {
    const candidates: Array<{ model: "Alpha" | "Evergreen" | "Legacy"; date: string }> = [];
    if (user.Alpha_Expiry) candidates.push({ model: "Alpha", date: user.Alpha_Expiry });
    if (user.Evergreen_Expiry)
      candidates.push({ model: "Evergreen", date: user.Evergreen_Expiry });
    if (user.Legacy_Expiry) candidates.push({ model: "Legacy", date: user.Legacy_Expiry });

    for (const candidate of candidates) {
      const parsed = parseISO(candidate.date);
      if (!isValid(parsed)) continue;
      const days = differenceInCalendarDays(startOfDay(parsed), today);
      if (days > withinDays) continue;
      items.push({
        id: `${user.id}-${candidate.model}`,
        user: user.user ?? `tg:${user.telegram_id ?? "unknown"}`,
        telegramId: String(user.telegram_id ?? "—"),
        model: candidate.model,
        expiry: parsed.toISOString(),
        daysRemaining: days,
      });
    }
  }

  return items.sort((a, b) => a.daysRemaining - b.daysRemaining);
}

export function buildPaymentIssues(payments: MinimalPayment[]): PaymentIssue[] {
  return payments
    .filter((p) => p.status === "refunded" || p.status === "pending")
    .map((p) => ({
      id: `${p.section}::${p.customer}::${p.date}`,
      date: p.date,
      section: p.section,
      sectionLabel: SECTION_LABELS[p.section],
      customer: p.customer,
      item: p.item,
      amount: p.amount,
      reason: p.status as "refunded" | "pending",
    }))
    .slice(0, 50);
}

export { BOT_DEFAULT_PRICE, pickActiveBotModel };

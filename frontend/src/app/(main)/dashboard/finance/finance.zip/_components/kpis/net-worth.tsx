"use client";

import { Users } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export function NetWorth() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>
          <div className="flex items-center gap-2">
            <span className="grid size-7 place-content-center rounded-sm bg-muted">
              <Users className="size-5" />
            </span>
            Active Clients
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-0.5">
          <div className="flex items-center justify-between">
            <p className="font-medium text-xl tabular-nums">186</p>
            <span className="text-xs text-emerald-500">+12 MoM</span>
          </div>
          <p className="text-muted-foreground text-xs">This month</p>
        </div>
        <Separator />
        <p className="text-muted-foreground text-xs">All active trading accounts</p>
      </CardContent>
    </Card>
  );
}
